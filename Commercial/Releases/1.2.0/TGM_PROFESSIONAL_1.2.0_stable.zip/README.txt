﻿THE GOLD MIND PROFESSIONAL
Version 1.2.0 (stable)

Commercial package - Customer Portal licensing + MT5 EA deployment.
Core Trading Engine certified Build 421.

Quick start:
1. Run Setup.exe
2. Activate license
3. Confirm EA under MT5 Navigator -> The Gold Mind
4. Attach TheGoldMindAI_Professional to a chart
